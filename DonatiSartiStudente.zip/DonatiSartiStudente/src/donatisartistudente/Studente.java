/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package donatisartistudente;

/**
 *
 * @author utente
 */
public class Studente {
    
    private String nome;
    private String cognome;
    private int anno;
    private String indirizzo;
    private String sezione;
    private int numeroMaterie;
    private int[] voti;

    /**
     * 
     * @param nome  Nome dello studente.
     * @param cognome  Cognome dello studente.
     * @param anno  Anno di frequentazione dello studente
     * @param indirizzo  Indirizzo scolastico che pratica lo studente.
     * @param sezione  Sezione che frequenta lo studente.
     * @param numeroMaterie  Il numero delle materie che lo studente ha.
     */
    
    
    
    // costruttore
    public Studente(String nome, String cognome, int anno, String indirizzo, String sezione, int numeroMaterie) {
        this.nome = nome;
        this.cognome = cognome;
        this.anno = anno;
        this.indirizzo = indirizzo;
        this.sezione = sezione;
        this.numeroMaterie = numeroMaterie;
        this.voti = new int[numeroMaterie];
    }

    // inserimento del nuovo voto nell'array
    public int inserisciVoto(int pos, int voto) {
        if (pos >= 0 && pos < numeroMaterie && voto >= 1 && voto <= 10) {
            voti[pos] = voto;
        }
        return 0;
    }

    // calcolo della media
    public double calcolaMedia() {
        if (numeroMaterie == 0) {
            return 0;
        }
        double somma = 0;
        for (int i = 0; i < numeroMaterie; i++) {
            somma = somma + voti[i];
        }
        return somma / numeroMaterie;
    }

    // voto massimo dello studente 
    public int getVotoMax() {
        if (numeroMaterie == 0) {
            return 0;
        }
        int max = voti[0];
        for (int i = 1; i < numeroMaterie; i++) {
            if (voti[i] > max) {
                max = voti[i];
            }
        }
        return max;
    }

    // voto minimo dello studente
    public int getVotoMin() {
        if (numeroMaterie == 0) {
            return 0;
        }
        int min = voti[0];
        for (int i = 1; i < numeroMaterie; i++) {
            if (voti[i] < min) {
                min = voti[i];
            }
        }
        return min;
    }

    // insufficienze dello studente
    public int contaInsufficienti() {
        int contatore = 0;
        for (int i = 0; i < numeroMaterie; i++) {
            if (voti[i] < 6) {
                contatore++;
            }
        }
        return contatore;
    }

    // media sufficiente
    public boolean haMediaSufficiente() {
        if (calcolaMedia() >= 6.0) {
            return true;
        }
        return false;
    }

    // metodi get e set
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCognome() {
        return cognome;
    }

    public void setCognome(String cognome) {
        this.cognome = cognome;
    }

    public int getAnno() {
        return anno;
    }

    public void setAnno(int anno) {
        this.anno = anno;
    }

    public String getIndirizzo() {
        return indirizzo;
    }

    public void setIndirizzo(String indirizzo) {
        this.indirizzo = indirizzo;
    }

    public String getSezione() {
        return sezione;
    }

    public void setSezione(String sezione) {
        this.sezione = sezione;
    }

    public int getNumeroMaterie() {
        return numeroMaterie;
    }

    public int[] getVoti() {
        return voti;
    }

    // metodo toString
    @Override
    public String toString() {
        String elencoVoti = "";
        for (int i = 0; i < numeroMaterie; i++) {
            elencoVoti = elencoVoti + voti[i] + " ";
        }

        return "Studente: " + nome + " " + cognome + 
               ", Classe: " + anno + " " + sezione + 
               ", Indirizzo: " + indirizzo + 
               ", Voti: " + elencoVoti + 
               ", Media: " + calcolaMedia() + 
               ", Voto Max: " + getVotoMax() + 
               ", Voto Min: " + getVotoMin() + 
               ", Insufficienti: " + contaInsufficienti() + 
               ", Sufficiente: " + haMediaSufficiente();
    }
}



