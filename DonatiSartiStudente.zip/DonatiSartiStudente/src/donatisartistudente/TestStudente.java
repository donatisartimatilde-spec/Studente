/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package donatisartistudente;
import java.util. *;

/**
 *
 * @author utente
 */
public class TestStudente {
    
     public void avvia(){
    
    Scanner scanner = new Scanner(System.in);

      
        // primo studente 
        System.out.println(" INSERIMENTO PRIMO STUDENTE ");
        
        System.out.print("Nome: ");
        String nome1 = scanner.next();

        System.out.print("Cognome: ");
        String cognome1 = scanner.next();

        System.out.print("Anno: ");
        int anno1 = scanner.nextInt();

        System.out.print("Indirizzo: ");
        String indirizzo1 = scanner.next();

        System.out.print("Sezione: ");
        String sezione1 = scanner.next();

        System.out.print("Numero materie: ");
        int numeroMaterie1 = scanner.nextInt();

        // creazione dell'oggetto del primo studente
        Studente st1 = new Studente(nome1, cognome1, anno1, indirizzo1, sezione1, numeroMaterie1);

        // inserimento dei voti per il primo studente
        System.out.println("Inserisci i voti:");
        for (int i = 0; i < numeroMaterie1; i++) {
            System.out.print("Voto " + (i + 1) + ": ");
            int voto = scanner.nextInt();
            st1.inserisciVoto(i, voto);
        }

        // secondo studente
        System.out.println("\n INSERIMENTO SECONDO STUDENTE ");
        
        System.out.print("Nome: ");
        String nome2 = scanner.next();

        System.out.print("Cognome: ");
        String cognome2 = scanner.next();

        System.out.print("Anno: ");
        int anno2 = scanner.nextInt();

        System.out.print("Indirizzo: ");
        String indirizzo2 = scanner.next();

        System.out.print("Sezione: ");
        String sezione2 = scanner.next();

        System.out.print("Numero materie: ");
        int numeroMaterie2 = scanner.nextInt();

        // creazione dell'oggetto del secondo studente
        Studente st2 = new Studente(nome2, cognome2, anno2, indirizzo2, sezione2, numeroMaterie2);

        // inserimento dei voti per il secondo studente
        System.out.println("Inserisci i voti:");
        for (int i = 0; i < numeroMaterie2; i++) {
            System.out.print("Voto " + (i + 1) + ": ");
            int voto = scanner.nextInt();
            st2.inserisciVoto(i, voto);
        }

      
        // stampa delle pagelle
        System.out.println("\n RISULTATI ");
        System.out.println(st1.toString());
        System.out.println(st2.toString());

       
        // confronto delle medie tra i due studenti
        System.out.println("\n CONFRONTO MEDIE ");
        
        if (st1.calcolaMedia() > st2.calcolaMedia()) {
            System.out.println("Lo studente con la media piu' alta e: " + st1.getNome() + " " + st1.getCognome());
        } else if (st2.calcolaMedia() > st1.calcolaMedia()) {
            System.out.println("Lo studente con la media piu' alta e: " + st2.getNome() + " " + st2.getCognome());
        } else {
            System.out.println("I due studenti hanno la stessa media.");
        }

    }
}
    
    





